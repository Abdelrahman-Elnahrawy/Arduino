var searchData=
[
  ['uint64tostring_3612',['uint64ToString',['../IRutils_8cpp.html#a9f6ddef74b41ef6f8d2805fcfc396420',1,'uint64ToString(uint64_t input, uint8_t base):&#160;IRutils.cpp'],['../IRutils_8h.html#a781650451d38303e80da677539f574ee',1,'uint64ToString(uint64_t input, uint8_t base=10):&#160;IRutils.cpp']]],
  ['uint8tobcd_3613',['uint8ToBcd',['../namespaceirutils.html#a534704a52b75acd46f687cc0a2b91bf1',1,'irutils']]],
  ['unithours_3614',['UnitHours',['../unionTecoProtocol.html#a53501f83a1d730135ec75bfb5838821b',1,'TecoProtocol']]],
  ['unknown_3615',['unknown',['../unionFujitsuProtocol.html#a1ffda1931475b743913abe2aad2138e3',1,'FujitsuProtocol::unknown()'],['../unionHaierProtocol.html#aabc2a684c5936858544c02ec8a68afb9',1,'HaierProtocol::unknown()'],['../IRremoteESP8266_8h.html#ad5b287a488a8c1b7b8661f029ab56fada6ce26a62afab55d7606ad4e92428b30c',1,'UNKNOWN():&#160;IRremoteESP8266.h']]],
  ['unknown1_3616',['unknown1',['../unionGreeProtocol.html#ae973c1c723b7162959374e1fd8ecab61',1,'GreeProtocol']]],
  ['unknown2_3617',['unknown2',['../unionGreeProtocol.html#aa102f7d68c26f5b8644b13113a5b05f4',1,'GreeProtocol']]],
  ['unused_3618',['UNUSED',['../IRremoteESP8266_8h.html#ad5b287a488a8c1b7b8661f029ab56fadaa09b651ef326a9d8efcee5cc5b720ab4',1,'IRremoteESP8266.h']]],
  ['updateandsavestate_3619',['updateAndSaveState',['../classIRCoolixAC.html#a2681a6affc5fb542584b1ef241bc38af',1,'IRCoolixAC']]],
  ['updatechecksums_3620',['updateChecksums',['../namespaceIRXmpUtils.html#a0ada8200316c402f268dd621a3b0695a',1,'IRXmpUtils']]],
  ['updateuselongorshort_3621',['updateUseLongOrShort',['../classIRFujitsuAC.html#a0c2aed356899787b8cd51b76b59e01bb',1,'IRFujitsuAC']]],
  ['usecmd_3622',['UseCmd',['../unionVestelProtocol.html#ae82716fdc06ba75def19a130d60d9e83',1,'VestelProtocol']]],
  ['used_3623',['used',['../structmatch__result__t.html#a26cea305aa83ed65b88ac0b6ed6de54a',1,'match_result_t']]],
  ['usefah_3624',['UseFah',['../unionNeoclimaProtocol.html#ae60408715008e78ab8058ab024669955',1,'NeoclimaProtocol::UseFah()'],['../unionTechnibelProtocol.html#a118cbcb15250c35ee423062e5f397662',1,'TechnibelProtocol::UseFah()']]],
  ['usefahrenheit_3625',['useFahrenheit',['../unionMideaProtocol.html#a1b1258107620bb83fd6356815242e19b',1,'MideaProtocol::useFahrenheit()'],['../unionGreeProtocol.html#a47c79761efe40c00e6bb01b7712b272c',1,'GreeProtocol::UseFahrenheit()']]]
];
